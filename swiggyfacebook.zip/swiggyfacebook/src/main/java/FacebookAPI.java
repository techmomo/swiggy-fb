
import java.io.FileReader;
import java.io.IOException;

import com.facebook.ads.sdk.APIContext;
import com.facebook.ads.sdk.AdAccount;
import com.facebook.ads.sdk.AdCreative;
import com.facebook.ads.sdk.AdSet;
import com.facebook.ads.sdk.Campaign;
import com.facebook.ads.sdk.CustomAudience;
import com.facebook.ads.sdk.Targeting;
import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonPrimitive;
import com.facebook.ads.sdk.CustomAudience.EnumSubtype;
import com.facebook.ads.sdk.APIException;
import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvException;

public class FacebookAPI {

    public static final String ACCESS_TOKEN = "access-token";
    public static final Long ACCOUNT_ID = Long.MIN_VALUE;
    public static final String APP_SECRET = "secret-key";
    public static final APIContext context = new APIContext(ACCESS_TOKEN, APP_SECRET).enableDebug(true);
    public static String csvFilePath= "some.csv";

    private AdAccount account;

    FacebookAPI(){
        account= new AdAccount(ACCOUNT_ID, context);
    }

    public JsonArray getAudience(){
        try{
            return account.getCustomAudiences().execute().getRawResponseAsJsonObject().getAsJsonArray("data");
        }catch(APIException ex){
            ex.printStackTrace();
            System.err.println("ex "+ex.getMessage());
        }
        return null;
    }
    public void createAudience(){
        try {

            CustomAudience audience = account.createCustomAudience()
                    .setName("Swiggy Custom Audience")
                    .setDescription("Swiggy Audience")
                    .setSubtype(EnumSubtype.VALUE_CUSTOM)
                    .execute();

            JsonArray payload= new JsonArray();

            buildFbAudiencePayload(csvFilePath,payload);
            audience.createUser()
                    .setPayload(payload.toString())
                    .execute();

            Targeting targeting = new Targeting().setFieldCustomAudiences("[{id:" + audience.getId() + "}]");

            // i am assuming this is beyond the scope of this task

//            Campaign campaign = account.createCampaign()
//                    .setName("Swiggy Campaign")
//                    .setObjective(Campaign.EnumObjective.VALUE_LINK_CLICKS)
//                    .setSpendCap(10000L)
//                    .setStatus(Campaign.EnumStatus.VALUE_PAUSED)
//                    .execute();
//
//            AdSet adset = account.createAdSet()
//                    .setName("Swiggy AdSet")
//                    .setCampaignId(campaign.getFieldId())
//                    .setStatus(AdSet.EnumStatus.VALUE_PAUSED)
//                    .setBillingEvent(AdSet.EnumBillingEvent.VALUE_IMPRESSIONS)
//                    .setDailyBudget(1000L)
//                    .setBidAmount(100L)
//                    .setOptimizationGoal(AdSet.EnumOptimizationGoal.VALUE_IMPRESSIONS)
//                    .setTargeting(targeting)
//                    .setRedownload(true)
//                    .requestAllFields()
//                    .execute();
//
//            AdCreative creative = account.createAdCreative()
//                    .setTitle("Swiggy Creative")
//                    .setBody("Swigy Creative")
//                    .setLinkUrl("www.facebook.com")
//                    .setObjectUrl("www.facebook.com")
//                    .execute();
//
//            account.createAd()
//                    .setName("Swiggy Ad")
//                    .setAdsetId(Long.parseLong(adset.getId()))
//                    .setCreative(creative)
//                    .setStatus("PAUSED")
//                    .setBidAmount(100L)
//                    .setRedownload(true)
//                    .execute();
        } catch (APIException e) {
            e.printStackTrace();
        }
    }

    public void buildFbAudiencePayload(String filePath,final JsonArray schema) {

        // Audience payload schema
        schema.add(new JsonPrimitive("FIRSTNAME"));
        schema.add(new JsonPrimitive("LASTNAME"));
        schema.add(new JsonPrimitive("EMAIL"));
        schema.add(new JsonPrimitive("MOBILE"));

        try {
            CSVReader csvReader = new CSVReader(new FileReader(filePath));
            csvReader.skip(1); // dont read header row
            JsonArray data = new JsonArray();
            csvReader.readAll().forEach(row-> {
                JsonArray personA = new JsonArray();
                personA.add(row[0]);
                personA.add(row[1]);
                personA.add(row[2]);
                personA.add(row[3]);
                data.add(personA);
            });
            JsonObject payload = new JsonObject();
            payload.add("schema", schema);
            payload.add("data", data);
        }catch (CsvException | IOException ex){
            System.err.println("ex "+ex.getMessage());
        }
    }
}
