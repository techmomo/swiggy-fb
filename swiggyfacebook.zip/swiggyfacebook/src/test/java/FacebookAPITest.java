import com.google.gson.JsonArray;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class FacebookAPITest {

    private final FacebookAPI facebookAPI = new FacebookAPI();

    @Test
    public void testCreateAudience(){
        facebookAPI.createAudience();

        // test if the audience has been created successfully or not
        JsonArray actual = facebookAPI.getAudience();
        JsonArray expected = new JsonArray();
        facebookAPI.buildFbAudiencePayload(FacebookAPI.csvFilePath,expected);

        expected.getAsJsonObject()
                .getAsJsonArray("data")
                .forEach(expected1->{
                actual.getAsJsonObject().getAsJsonArray("data").forEach(actual1->{
                    // we can drill down further for individual column verification
                    Assertions.assertEquals(expected1,actual1);
                });
        });
    }
}
